package com.credentials.main;

import java.util.Scanner;

import com.credentials.model.Employee;
import com.credentials.service.Credentials;

public class DriverClass {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("First Name");
		String FirstName=sc.nextLine();
		System.out.println("LastName");
		String LastName=sc.nextLine();
		Employee e1=new Employee(FirstName,LastName);
		Credentials c=new Credentials();
		System.out.println("Please enter the department from the following");
		System.out.println("1.Technical\n2.Admin\n3.Human Resource\n4.Legal");
		int choose =sc.nextInt();
		switch(choose) {
		case 1:
			c.showCredentials(e1, "Tech");
			break;
		case 2:
			c.showCredentials(e1, "Admin");
			break;
		case 3:
			c.showCredentials(e1, "Human Resource");
			break;
		case 4:
			c.showCredentials(e1, "legal");
			break;
		}
	}
}
