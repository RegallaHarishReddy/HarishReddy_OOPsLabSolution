package com.credentials.model;

public class Employee {
	String FirstName;
	String Lastname;
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public Employee(String firstName, String lastname) {
		super();
		FirstName = firstName;
		Lastname = lastname;
	}
	
}
