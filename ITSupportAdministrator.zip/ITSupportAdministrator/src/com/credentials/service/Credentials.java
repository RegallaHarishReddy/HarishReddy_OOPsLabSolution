package com.credentials.service;

import java.util.Random;

import com.credentials.model.Employee;

public class Credentials {
 
	private char[] generatePassword(){
		int length=8;
		String lower_case="abcdefghijklmnopqrstuvwxyz";
		String upper_case="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String number="1234567890";
		String symbols="!@#$%^&*_+=-/.?<>)";
		String values=lower_case+upper_case+number+symbols;
		Random rnd_method=new Random();
		char[] password =new char[length];
		for (int i=0;i<length;i++) {
			password[i]=values.charAt(rnd_method.nextInt(values.length()));
		}
		return password;
	}
	private String generateEmail(Employee e1, String department) {
		return e1.getFirstName().toLowerCase()+e1.getLastname().toLowerCase()+"@"+department+".abc.com";
	}
	public void showCredentials(Employee e1, String department) {
		System.out.println("Dear "+e1.getFirstName()+" your generated credentials are as follow");
		System.out.println(this.generateEmail(e1,department));
		System.out.println(this.generatePassword());
	}
}
